#!/sbin/sh
find /vendor/etc -name "fstab.*" -exec sed -i 's/discard,//g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/errors=panic//g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/forceencrypt/encryptable/g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/forcefdeorfbe/encryptable/g' {} +
find /vendor/etc -name "fstab.*" -exec sed -i 's/fileencryption/encryptable/g' {} +

find /system/vendor/etc -name "fstab.*" -exec sed -i 's/discard,//g' {} +
find /system/vendor/etc -name "fstab.*" -exec sed -i 's/errors=panic//g' {} +
find /system/vendor/etc -name "fstab.*" -exec sed -i 's/forceencrypt/encryptable/g' {} +
find /system/vendor/etc -name "fstab.*" -exec sed -i 's/forcefdeorfbe/encryptable/g' {} +
find /system/vendor/etc -name "fstab.*" -exec sed -i 's/fileencryption/encryptable/g' {} +